<?php
namespace src\models;
use \core\Model;

class Post extends Model {

}