<?php
namespace src\models;
use \core\Model;

class UserRelation extends Model {

}