<?php
namespace src\models;
use \core\Model;

class Test extends Model {

}