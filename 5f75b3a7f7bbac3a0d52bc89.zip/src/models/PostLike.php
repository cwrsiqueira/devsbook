<?php
namespace src\models;
use \core\Model;

class PostLike extends Model {

}